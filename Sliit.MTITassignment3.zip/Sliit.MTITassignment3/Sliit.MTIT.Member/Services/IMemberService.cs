﻿namespace Sliit.MTIT.Member.Services
{
    public interface IMemberService
    {

        List<Models.Member> GetMembers();
        Models.Member? GetMember(int id);
        Models.Member? AddMember(Models.Member member);
        Models.Member? UpdateMember(Models.Member member);
        bool? DeleteMember(int id);
    }
}
