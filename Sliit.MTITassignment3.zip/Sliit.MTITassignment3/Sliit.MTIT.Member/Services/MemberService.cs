﻿
using Sliit.MTIT.Member.Data;
using Sliit.MTIT.Member.Models;
namespace Sliit.MTIT.Member.Services
{
    
        public class MemberService : IMemberService
        {
            public List<Models.Member> GetMembers()
            {
                return MemberMockDataService.Members;
            }

            public Models.Member? GetMember(int id)
            {
                return MemberMockDataService.Members.FirstOrDefault(x => x.Id == id);
            }

            public Models.Member? AddMember(Models.Member member)
            {
                MemberMockDataService.Members.Add(member);
            return member ;
            }

            public Models.Member? UpdateMember(Models.Member member)
            {
                Models.Member selectedMember = MemberMockDataService.Members.FirstOrDefault(x => x.Id == member.Id);
                if (selectedMember != null)
                {
                    selectedMember.Name = member.Name;
                    selectedMember. Mobile = member.   Mobile;
                    selectedMember.Email = member.Email;
                    selectedMember.Username = member.Username;
                    selectedMember.Password = member.Password;
               
                    return selectedMember;
                }

                return selectedMember;
            }

            public bool? DeleteMember(int id)
            {
                Models.Member selectedMember = MemberMockDataService.Members.FirstOrDefault(x => x.Id == id);
                if (selectedMember != null)
                {
                   MemberMockDataService.Members.Remove(selectedMember);
                    return true;
                }
                return false;
            }
        }
    }

