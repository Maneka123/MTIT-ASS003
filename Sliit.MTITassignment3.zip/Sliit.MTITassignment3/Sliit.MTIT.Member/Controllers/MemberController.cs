﻿
using System.Reflection.Metadata.Ecma335;
using Microsoft.AspNetCore.Mvc;
using Sliit.MTIT.Member.Data;
using Sliit.MTIT.Member.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Sliit.MTIT.Member.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private readonly IMemberService _memberService;

        public MemberController(IMemberService memberService)
        {
            _memberService = memberService ?? throw new ArgumentNullException(nameof(memberService));
        }


        /// <summary>
        /// Get all students
        /// </summary>
        /// <returns>return the list of students</returns>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_memberService.GetMembers());
        }

        /// <summary>
        /// Get student by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Return the student with the passed ID</returns>
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            return _memberService.GetMember(id) != null ? Ok(_memberService.GetMember(id)) : NoContent();
        }

        /// <summary>
        /// Add students
        /// </summary>
        /// <param name="member"></param>
        /// <returns>Return the added student</returns>
        [HttpPost]
        public IActionResult Post([FromBody] Models.Member member)
        {
            return Ok(_memberService.AddMember(member));
        }

        /// <summary>
        /// Update the student
        /// </summary>
        /// <param name="member"></param>
        /// <returns>Return the updated student</returns>
        [HttpPut]
        public IActionResult Put([FromBody] Models.Member member)
        {
            return Ok(_memberService.UpdateMember(member));
        }

        /// <summary>
        /// Delete the student with the passed ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var result = _memberService.DeleteMember(id);

            return result.HasValue & result == true ? Ok($"member with ID:{id} got deleted successfully.")
                : BadRequest($"Unable to delete the member with ID:{id}.");
        }
    }
}
