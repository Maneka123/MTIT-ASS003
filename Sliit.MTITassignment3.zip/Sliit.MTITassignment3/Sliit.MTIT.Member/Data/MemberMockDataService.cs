﻿using System.Reflection;

namespace Sliit.MTIT.Member.Data
{
    public class MemberMockDataService
    {
        public static List<Models.Member> Members = new List<Models.Member>()
        {
            new Models.Member { Id = 1, Name = "Audrey", Address = "8268 Myers Street West Orange, NJ 07052", Email = "audrey@gmail.com",Username="Aud",Password="abc123",Mobile=0123456 },
            new Models.Member { Id = 2, Name = "Bobby", Address = "9 Annadale Drive Sacramento, CA 95820", Email = "bobby@gmail.com",Username="Bob",Password="abc456",Mobile=077321 },
            new Models.Member { Id = 3, Name = "Cathy", Address = "69 Roehampton Ave.Macon, GA 31204", Email = "cathy@gmail.com",Username="Cat",Password="abc789",Mobile=077789},
            new Models.Member { Id = 4, Name = "Dorothy", Address = "69 Roehampton Ave.Macon, GA 3120421 Silver Spear Avenue Smithtown, NY 11787", Email = "dorothy@gmail.com",Username="Dor",Password="abc741",Mobile=07774123},
            new Models.Member { Id = 5, Name = "Emminia", Address = "75 Indian Summer Avenue Findlay, OH 45840", Email = "emminia@gmail.com",Username="Emmy",Password="abc852",Mobile=0777852369},
            
            /*new Models.Student { Id = 2, Name = "Mary", Address = "456 Second Ave", Age = 22 },
            new Models.Student { Id = 3, Name = "Tom", Address = "789 Third St", Age = 21 },
            new Models.Student { Id = 4, Name = "Kate", Address = "321 Fourth Ave", Age = 23 },
            new Models.Student { Id = 5, Name = "Mike", Address = "654 Fifth St", Age = 19 }*/
        };
    }
}
